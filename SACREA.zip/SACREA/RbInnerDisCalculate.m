function [R_b,R_bRecord] = RbInnerDisCalculate(SurroNew,R_bRecord,SubPopulation)
    if isempty(SurroNew)
        R_b = 0;
        R_bRecord = [R_bRecord,R_b];
%     else 
    else
        %% Normalization
        PopObj = [SubPopulation.objs;SurroNew.objs];
        Zmin   = min(PopObj,[],1);
        Zmax   = max(PopObj,[],1);
        PopObj = (PopObj-repmat(Zmin,size(PopObj,1),1))./repmat(Zmax-Zmin,size(PopObj,1),1);
        %% Calculate the fitness value of each solution
        fit = sum(PopObj,2);
        PopSize1 = length(SubPopulation);
        R_b = max((min(fit(1:PopSize1)) - min(fit(PopSize1+1:end))) / min(fit(1:PopSize1)), 0);
        R_bRecord = [R_bRecord,R_b];
    end
end