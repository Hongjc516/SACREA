function [R_sJudge,RecordAcc] = RSJudgement(KrigingNew,KrigingSelectedOldObj,RecordAcc)
    SelectedNewObj = KrigingNew.objs;
    SelectedOldObj = KrigingSelectedOldObj;
    for i = 1:size(SelectedNewObj,1)
        for j = 1:size(SelectedNewObj,2)
            SelectedNewObj(i,j) = max(SelectedNewObj(i,j),0.000001);
            SelectedOldObj(i,j) = max(SelectedOldObj(i,j),0.000001);
        end
    end
    JudgeNext = [];
    if ~isempty(SelectedNewObj)
        JudgePar = abs((SelectedNewObj-SelectedOldObj)./SelectedNewObj);
        for ii = 1:size(JudgePar,1)
            for jj = 1:size(JudgePar,2)
                if JudgePar(ii,jj)<0.1
                    JudgeNext(ii,jj) = 0.5;
                else
                    JudgeNext(ii,jj) = 0;
                end
            end
        end
        aaa = (sum(JudgeNext,2)'==1);
        if ~isempty(aaa)
            bbb = sum(aaa)./(size(SelectedNewObj,1));
        end
        RecordAcc = [RecordAcc,bbb];
    end
    if length(RecordAcc) > 4
        if sum(RecordAcc(end-4:end))>3.5
            R_sJudge = true;
        else
            R_sJudge = false;
        end
    else
        R_sJudge = false;
    end
end