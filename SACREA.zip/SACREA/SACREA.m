classdef SACREA < ALGORITHM
% <multi> <real/integer/label/binary/permutation> <robust>
% Multifactorial evolutionary algorithm
% rmp --- 0.3 --- Random mating probability

%------------------------------- Reference --------------------------------
% A. Gupta, Y. Ong, and L. Feng, Multifactorial evolution: towards
% evolutionary multitasking, IEEE Transactions on Evolutionary Computation,
% 2016, 20(3): 343-357.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            F = 0.5;
            CR = 0.9;
            Alpha = 0.5;
            Gama = 0.85;
            Pmin = 0.1;
            T = 2;
            Gen = 2;
            THETA      = 5.*ones(Problem.M,Problem.D-1);
            THETA2 = THETA;
            PerturbDelta = 0.05;
            PerturbH = 50;
            CountKriRecord = 0;

            %% Initialize population
            KriNI    = 11*Problem.D-1;
            RBFNI    = 11*Problem.D-1;
            SubD     = Problem.D-1;
            [RBFPBW,~] = UniformPoint(RBFNI,Problem.M);
            KriP     = UniformPoint(KriNI,SubD,'Latin');
            SubPopulation{1} = Problem.Evaluation(repmat(Problem.upper-Problem.lower,KriNI,1).*KriP+repmat(Problem.lower,KriNI,1));  %xunlianji
            RBFP     = UniformPoint(KriNI,SubD,'Latin');
            SubPopulation{2} = Problem.Evaluation(repmat(Problem.upper-Problem.lower,RBFNI,1).*RBFP+repmat(Problem.lower,RBFNI,1));
            HR = []; % HR is used to store the historical rewards
            maxGen = round((Problem.maxFE-6240)/100);
            delta_rmp = 1 / maxGen;
            RMP = [0.7,0.3;0.3,0.7];
            RecordAcc = [];
            R_bRecord = [];
            R_cRecord = [];
            KrigingNew = [];
            RBFNew = [];
            
            
            RBFZmin  = min(SubPopulation{2}.objs,[],1);
            CountFE2 = 0;
            wmax1 = 20;
            wmax2 = 20;

            %% Initialization Perturbation
            PerturbSurroPopulation = SubPopulation{1};
            PerturbPopObj = PerturbSurroPopulation.objs;
            PerturbPopDec = PerturbSurroPopulation.decs;
            PerturbPopCon = PerturbSurroPopulation.cons;
            for i = 1:size(PerturbPopDec,1)
                TemDelta = repmat(PerturbDelta.*(Problem.upper-Problem.lower),PerturbH*size(PerturbPopDec(i,:),1),1);
                PerturbW     = UniformPoint(PerturbH,SubD,'Latin');
                PerturbDec   = 2*TemDelta.*PerturbW(reshape(repmat(1:end,size(PerturbPopDec(i,:),1),1),1,[]),:) + repmat(PerturbPopDec(i,:),PerturbH,1) - TemDelta;
                PerturbDec   = Problem.CalDec(PerturbDec);
                PerturbOffPopulation   = Problem.Evaluation(PerturbDec);
                PerturbOffObj = PerturbOffPopulation.objs;
                PerturbPopObj(i,:) = mean(PerturbOffObj,1);
            end
            KriZmin  = min(PerturbPopObj,[],1);
            PerturbPopDec(:,end+1) = 1;
            SubPopulation{1} = SOLUTION(PerturbPopDec,PerturbPopObj,PerturbPopCon);
            Sub2PopObj = SubPopulation{2}.objs;
            Sub2PopDec = SubPopulation{2}.decs;
            Sub2PopCon = SubPopulation{2}.cons;
            Sub2PopDec(:,end+1) = 2;
            SubPopulation{2} = SOLUTION(Sub2PopDec,Sub2PopObj,Sub2PopCon);
            RBFTrainSet = SubPopulation{2};
            AllKriPopulation = SubPopulation{1};

            

            %% Optimization
            while Algorithm.NotTerminated([SubPopulation{1}]) 
                KrigingSelectedOldObj = [];
                KriMse = zeros(length(SubPopulation{1}),size(Sub2PopObj,2));
                % Select the k-th task to optimize
                if Gen <= 30%Beta * maxGen 
                    k = unidrnd(T);
                else
                    weights = Gama.^(Gen - 3:-1:0);
                    sum_weights = sum(weights);
                    for t = 1:T
                        mean_R(t) = sum(weights .* HR(t, :)) / sum_weights;
                    end
                    % The selection probability
                    prob(Gen, :) = Pmin / T + (1 - Pmin) * mean_R ./ (sum(mean_R));

                    % Determine the a task based on the selection probability using roulette wheel method
                    k = RouletteSelection(prob(Gen, :));
                end

                %% Surrogate Build
                D2Dec = SubPopulation{1}.decs;
                D2Dec(:,end) = [];
                D2Obj = SubPopulation{1}.objs;
                [D1Dec,D1Obj] = dsmerge(D2Dec,D2Obj);
                for i = 1 : Problem.M
                     dmodel     = dacefit(D1Dec,D1Obj(:,i),'regpoly0','corrgauss',THETA(i,:),1e-5.*ones(1,Problem.D-1),100.*ones(1,Problem.D-1));
                     Model{i}   = dmodel;
                     THETA(i,:) = dmodel.theta;
                end

                D4Dec = SubPopulation{2}.decs;
                D4Dec(:,end) = [];
                D4Obj = SubPopulation{2}.objs;
                [~,RBFdistinct] = unique(round(D4Dec*1e6)/1e6,'rows');
                D3Dec = D4Dec(RBFdistinct,:);
                D3Obj = D4Obj(RBFdistinct,:);
                for i = 1 : Problem.M
                     dmodel2     = dacefit(D3Dec,D3Obj(:,i),'regpoly0','corrgauss',THETA2(i,:),1e-5.*ones(1,Problem.D-1),100.*ones(1,Problem.D-1));
                     Model2{i}   = dmodel2;
                     THETA2(i,:) = dmodel2.theta;
                end

                
                %% Kriging Loop
                w1     = 1;
                w2     = 1;
                KrigingArc = SubPopulation;
                if k == 1
                    FrontNo = NDSort(AllKriPopulation.objs,KriNI);
                    CompPop = AllKriPopulation(FrontNo<=1);
                    Lp      = PIMDShape_Estimate(SubPopulation{1},KriNI);
                    while w1 <= wmax1
                        KrigingPopulation = KrigingArc{1};
                        KrigingOffCon = KrigingPopulation.cons;
                        [KrigingOffDec, r1_task] = Generation(Problem,KrigingArc, RMP, k, F, CR, T);
                        KrigingOffDec(:,end) = [];
                        for i = 1: size(KrigingOffDec,1)                                 % real FE
                            for j = 1 : Problem.M
                                [KrigingOffObj(i,j),~,MSE(i,j)] = KrigingPredictor(KrigingOffDec(i,:),Model{j});
                            end
                        end
                        KrigingOffDec(:,end+1) = 1;
                        KrigingPopulation = SOLUTION(KrigingOffDec,KrigingOffObj,KrigingOffCon);       
                        KriPopFit = KrigingArc{1}.objs;
                        KriParDec = KrigingArc{1}.decs;
                        KriZmin  = min([KriZmin; KrigingOffObj],[],1);
                        Kriall_Obj = [KriPopFit;KrigingOffObj];
                        all_Mse = [KriMse;MSE];
                        Kriall_Dec = [KriParDec;KrigingOffDec];
                        [KriInFrontNo,KriInMaxFNo] = NDSort(Kriall_Obj,KriNI);
                        KriInNext = KriInFrontNo < KriInMaxFNo;
                        KriLast   = find(KriInFrontNo==KriInMaxFNo);  
                        Krireplace = PBLastSelection(Kriall_Obj(KriInNext,:),Kriall_Obj(KriLast,:),KriNI-sum(KriInNext),RBFPBW,KriZmin); 
                        KriInNext(KriLast(Krireplace)) = true;
                        KriNewDec = Kriall_Dec(KriInNext,:);
                        KriNewObj = Kriall_Obj(KriInNext,:);
                        KriMse = all_Mse(KriInNext,:);
                        KriPopulation  = SOLUTION(KriNewDec,KriNewObj,KrigingOffCon);
                        KrigingArc{k} = KriPopulation;

                        w1 = w1+1;
                    end
                    KrigingChoose = PBSelection(SubPopulation{k},KriNewObj);  %PB采样策略
                    KriOnceChooseJudge = sum(KrigingChoose);
                    KrigingPerturbPopulation = KrigingArc{k}(KrigingChoose);
                    if KriOnceChooseJudge > 8
                        KrigingPerturbPopulation = PIMDSelection(KrigingPerturbPopulation.decs,KrigingPerturbPopulation.objs,CompPop,KriMse(KrigingChoose,:),Lp,KrigingPerturbPopulation);
                    end
                    if KriOnceChooseJudge > 8
                        CountKriRecord = CountKriRecord+1;
                    end
                    KrigingSelectedOldObj = KrigingPerturbPopulation.objs;
                    KriPerturbPopObj = KrigingPerturbPopulation.objs;
                    KriPerturbPopDec = KrigingPerturbPopulation.decs;
                    KriPerturbPopCon = KrigingPerturbPopulation.cons;
                    KriPerturbPopDec(:,end) = [];
                    for i = 1:size(KriPerturbPopDec,1)
                        TemDelta = repmat(PerturbDelta.*(Problem.upper-Problem.lower),PerturbH*size(KriPerturbPopDec(i,:),1),1);
                        PerturbW     = UniformPoint(PerturbH,SubD,'Latin');
                        KriPerturbDec   = 2*TemDelta.*PerturbW(reshape(repmat(1:end,size(KriPerturbPopDec(i,:),1),1),1,[]),:) + repmat(KriPerturbPopDec(i,:),PerturbH,1) - TemDelta;
                        KriPerturbDec   = Problem.CalDec(KriPerturbDec);
                        KriPerturbOffPopulation   = Problem.Evaluation(KriPerturbDec);
                        KriPerturbOffObj = KriPerturbOffPopulation.objs;
                        KriPerturbPopObj(i,:) = mean(KriPerturbOffObj,1);
                    end
                    KriPerturbPopDec(:,end+1) = 1;
                    KrigingNew = SOLUTION(KriPerturbPopDec,KriPerturbPopObj,KriPerturbPopCon);
                    [R_b,R_bRecord] = RbInnerDisCalculate(KrigingNew,R_bRecord,SubPopulation{k});
                    AllKriPopulation = [AllKriPopulation,KrigingNew];
                    A3   = [SubPopulation{k},KrigingNew];
                    KriZmin = min(A3.objs,[],1);
                    [SubPopulation{k},R_p,NextNew] = PBEnvironmentalSelection(A3,KriNI,RBFPBW,KriZmin); %PB种群更新
                end
                %% RBF Evolution
  
                RBFArc = SubPopulation;
                if k == 2
                    while w2 <= wmax2
                        RBFPopulation = RBFArc{k};
                        RBFPopObj = RBFPopulation.objs;
                        RBFPopCon = RBFPopulation.cons;

                        [RBFOffDec, r1_task] = Generation(Problem,RBFArc, RMP, k, F, CR, T);
                        RBFOffDec(:,end) = [];

                        PerturbM = size(RBFPopObj,2);
                        RBFOffObj = zeros(size(RBFPopObj,1),PerturbM);
                        for i = 1: size(RBFOffDec,1)                                 
                            for j = 1 : Problem.M
                                [RBFOffObj(i,j),~,~] = KrigingPredictor(RBFOffDec(i,:),Model2{j});
                            end
                        end
                        RBFOffDec(:,end+1) = 2;
                        RBFZmin  = min([RBFZmin; RBFOffObj],[],1);
                        w2 = w2+1;
                        RBFPopFit = RBFArc{k}.objs;
                        RBFParDec = RBFArc{k}.decs;
                        RBFall_Obj = [RBFPopFit;RBFOffObj];
                        RBFall_Dec = [RBFParDec;RBFOffDec];
                        [RBFInFrontNo,RBFInMaxFNo] = NDSort(RBFall_Obj,RBFNI);
                        RBFInNext = RBFInFrontNo < RBFInMaxFNo;
                        RBFLast   = find(RBFInFrontNo==RBFInMaxFNo);  
                        RBFreplace = PBLastSelection(RBFall_Obj(RBFInNext,:),RBFall_Obj(RBFLast,:),RBFNI-sum(RBFInNext),RBFPBW,RBFZmin); 
                        RBFInNext(RBFLast(RBFreplace)) = true;
                        RBFNewDec = RBFall_Dec(RBFInNext,:);
                        RBFNewObj = RBFall_Obj(RBFInNext,:);
                        RBFPopulation  = SOLUTION(RBFNewDec,RBFNewObj,RBFPopCon);
                        RBFArc{k} = RBFPopulation;
                    end
                    RBFChoose = PBSelection(SubPopulation{k},RBFNewObj);  %PB采样策略
                    RBFSelectedNewDec = RBFArc{k}(RBFChoose).decs;
                    RBFSelectedNewDec(:,end) = [];
                    RBFNew   = Problem.Evaluation(RBFSelectedNewDec);
                    RBFNewOffDec = RBFNew.decs;
                    RBFNewOffObj = RBFNew.objs;
                    RBFNewOffCon = RBFNew.cons;
                    RBFNewOffDec(:,end+1) = 2;
                    RBFNew = SOLUTION(RBFNewOffDec,RBFNewOffObj,RBFNewOffCon);
                    RBFTrainSet = [RBFTrainSet,RBFNew];
                    [R_b,R_bRecord] = RbInnerDisCalculate(RBFNew,R_bRecord,SubPopulation{k});
                    A2   = [SubPopulation{k},RBFNew];
                    RBFZmin = min(A2.objs,[],1);
                    [SubPopulation{k},R_p,NextNew] = PBEnvironmentalSelection(A2,RBFNI,RBFPBW,RBFZmin);  %非支配排序
                end

                %% Without Robust Selected

               % Calculate model accuracy
                    if k == 1
                        [~,RecordAcc] = RSJudgement(KrigingNew,KrigingSelectedOldObj,RecordAcc);
                    end
                    if k == 2
                        CountFE2 = CountFE2 + length(RBFNew);
                    end
 

                    % Gains from auxiliary task
                    if k == 1
                        Rc_taskMid = r1_task(KrigingChoose);
                        Rc_Task = Rc_taskMid(NextNew);
                        SurroNew = KrigingNew(NextNew);
                        RcCount = length(KrigingNew(NextNew));
                        R_cRecord = [R_cRecord,RcCount];
                    else
                        Rc_taskMid = r1_task(RBFChoose);
                        Rc_Task = Rc_taskMid(NextNew);
                        SurroNew = RBFNew(NextNew);
                        RcCount = length(RBFNew(NextNew));
                        R_cRecord = [R_cRecord,RcCount];
                    end
                    if isempty(R_p)
                        R_p = [delta_rmp];
                        SurroNew = [1];
                    end
                    if sum(R_p) == 0
                        SurroNew = [1];
                    end
                    R = zeros(T, 1);
              
                    for t = 1:T
                        if t == k %The main task
                                R(t) = Alpha * R_b + (1 - Alpha) * (sum(R_p) / length(SurroNew));
                        else % The auxiliary task
                            index = find(Rc_Task == t);
                            if isempty(index)
                                R(t) = 0;
                            else
                                R(t) =  (sum(R_p(index)) / length(index));
                            end
                            if sum(R_p) == 0
                                R(t) = Alpha * (length(find(Rc_taskMid==t))/length(Rc_taskMid));
                            end
                        end
                    end
                    HR = [HR, R];

                %% update RMP
                    if Gen>50 && ~isa(SurroNew,"double")
                        if k == 1
                            SurroPopulation = [SubPopulation{2},SurroNew];
                            [SurFrontNo,~] = NDSort(SurroPopulation.objs,length(SurroPopulation));
                            OldFront = sum(SurFrontNo(1:length(SubPopulation{2})))/length(SubPopulation{2});
                            NewFront = sum(SurFrontNo(length(SubPopulation{2})+1:end))/length(SurroNew);
                            RMPSortDelta = (OldFront-NewFront)/OldFront;
                        else
                            SurroPopulation = [SubPopulation{1},SurroNew];
                            [SurFrontNo,~] = NDSort(SurroPopulation.objs,length(SurroPopulation));
                            OldFront = sum(SurFrontNo(1:length(SubPopulation{1})))/length(SubPopulation{1});
                            NewFront = sum(SurFrontNo(length(SubPopulation{1})+1:end))/length(SurroNew);
                            RMPSortDelta = (OldFront-NewFront)/OldFront;
                        end
                        AdaptiveDelta = 1-(Problem.FE/Problem.maxFE);
                        deltaIncre = 0.005 * AdaptiveDelta * RMPSortDelta;
                        if k == 1 && deltaIncre >= 0
                            RMP(1, 1) = min(RMP(1, 1) + deltaIncre, 1);
                            RMP(1, 2) = max(RMP(1, 2) - deltaIncre, 0);
                        else
                            if k == 1 && deltaIncre < 0
                                RMP(1, 1) = max(RMP(1, 1) + deltaIncre, 0);
                                RMP(1, 2) = min(RMP(1, 2) - deltaIncre, 1);
                            elseif k == 2 && deltaIncre >= 0
                                RMP(2, 2) = min(RMP(2, 2) + deltaIncre, 1);
                                RMP(2, 1) = max(RMP(2, 1) - deltaIncre, 0);
                            else
                                RMP(2, 2) = max(RMP(2, 2) + deltaIncre, 0);
                                RMP(2, 1) = min(RMP(2, 1) - deltaIncre, 1);
                            end
                        end
                    end
                    Gen = Gen+1;
            end
        end
    end
end