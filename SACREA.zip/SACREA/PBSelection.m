function Choose = KriPBSelection(Population,Obj)
%                 DAdec = Dec;
                DA    = Population;
                % Normalization
                DA_Nor = (DA.objs - repmat(min([Obj;DA.objs],[],1),length(DA),1))...  
                    ./repmat(max([Obj;DA.objs],[],1) - min([Obj;DA.objs],[],1),length(DA),1);
                DA_Nor_pre = (Obj - repmat(min([Obj;DA.objs],[],1),size(Obj,1),1))...
                    ./repmat(max([Obj;DA.objs],[],1) - min([Obj;DA.objs],[],1),size(Obj,1),1);
                Zmin = min([DA_Nor;DA_Nor_pre],[],1);
                
                dist_D = zeros(size(DA_Nor_pre,1),size(DA_Nor,1));
                
                 % Calculate the distance between candidate solutions and parents
                for i = 1 : size(DA_Nor_pre,1)    
                    for j = 1 : size(DA_Nor,1)
                        dist_D(i,j) = norm(DA_Nor_pre(i,:)-DA_Nor(j,:),2);
                    end
                end
                
                % Diversity Indicator
                DI = -min(dist_D,[],2); 
                
                % Calculate the distance between candidate solutions and ideal point
                dist_C = pdist2(DA_Nor_pre,repmat(Zmin,size(DA_Nor_pre,1),1));
                
                % Convergence Indicator
                CI      = dist_C(:,1);
                newObj  = [DI,CI];
                ND1     = NDSort(newObj,1);
                Choose  = ND1 == 1;
%                 PnewDec = DAdec((ND1==1),:);  % find solutions in the first front
%                 PnewDec = unique(PnewDec,'rows');
end

