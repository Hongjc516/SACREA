function KrigingPerturbPopulation = PIMDSelection(Dec,Obj,CompPop,Mse,Lp,KrigingPerturbPopulation)
    eta = 5;
    deleteindex = find(sum(Mse,2)<10^-15);
    Dec(deleteindex,:) = [];
    Obj(deleteindex,:) = [];
    Mse(deleteindex,:) = [];
    KrigingPerturbPopulation(deleteindex) = [];
    % if ~isempty(deleteindex)
    %     ooooo = 1;
    % end
    Comobj = CompPop.objs;
    Pr_dominate = zeros(1,size(Obj,1));
    for i = 1 : size(Obj,1)
        Pr = normcdf(Comobj,repmat(Obj(i,:),size(Comobj,1),1), repmat(sqrt(max(Mse(i,:),0)),size(Comobj,1),1) );
        Pr_dominate(i) = -1*max(prod(Pr,2)); % Improvement of probability
    end
    
    [NormObj,NormCompare] = normalization411(Obj,CompPop.objs);
    tran_NormObj          = Obj_tran(NormObj,Lp);
    tran_NormCompare      = Obj_tran(NormCompare,Lp);
    dist = pdist2(tran_NormCompare,tran_NormObj); 
    DI   = -min(dist,[],1); %Mapping crowding distance
    newObj      = [DI;Pr_dominate]';
    [FrontNo,~] = NDSort(newObj,1);
    PnewDec     = Dec((FrontNo==1),:);  % Find solutions in the first front
    KrigingPerturbPopulation = KrigingPerturbPopulation(FrontNo==1);
    % [PnewDec,selectind] = unique(PnewDec,'rows');
    len = size(PnewDec,1);
    if size(PnewDec,1) > eta
        pr      = Pr_dominate(FrontNo==1);
        % [~,ind] = min(pr(selectind));
        [~,ind] = min(pr);
        temp    = randperm(len,eta);
        if ~ismember(ind,temp)
            temp(1) = ind;
        end
        PnewDec = PnewDec(temp,:);
        KrigingPerturbPopulation = KrigingPerturbPopulation(temp);
    end
end
function tran_Obj = Obj_tran(PopObj,Lp)
    PopObj   = PopObj+10^-6;
    tran_Obj = PopObj./(sum(abs(PopObj).^Lp,2)).^(1/Lp);  
end
